# Overview

RGPV Mates is a college dating application designed specifically for RGPV (Rajiv Gandhi Proudyogiki Vishwavidyalaya) students. The platform provides a secure, verified environment where students can connect with fellow classmates through a Tinder-like swiping interface. The application emphasizes safety and authenticity by requiring RGPV email verification and student ID card verification before users can start matching.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React + TypeScript**: Single-page application using React 18 with TypeScript for type safety
- **Vite**: Build tool and development server for fast hot module replacement
- **Wouter**: Lightweight routing library for client-side navigation
- **TanStack Query**: Data fetching and caching with background updates and optimistic updates
- **shadcn/ui + Radix UI**: Component library built on Radix primitives with Tailwind CSS styling
- **React Hook Form + Zod**: Form management with schema validation
- **Tailwind CSS**: Utility-first CSS framework with custom color variables for brand consistency

## Backend Architecture
- **Express.js**: RESTful API server with middleware for logging, error handling, and authentication
- **TypeScript + ESM**: Modern JavaScript with ES modules throughout the stack
- **Drizzle ORM**: Type-safe database queries with PostgreSQL dialect
- **Session-based Authentication**: Using connect-pg-simple for PostgreSQL session storage
- **Replit Auth Integration**: OAuth integration with Replit's authentication system

## Database Design
- **PostgreSQL**: Primary database using Neon serverless PostgreSQL
- **Drizzle Schema**: Type-safe schema definitions with relations
- **Core Tables**: users, profiles, swipes, matches, messages, payments, reports, sessions
- **Enums**: Predefined values for gender, academic branch, year, and verification status
- **Indexes**: Optimized queries with proper indexing on session expiration

## Key Features Architecture
- **Swipe System**: Card-based UI with gesture controls using react-spring and use-gesture
- **Real-time Matching**: Instant match detection when mutual likes occur
- **Profile Verification**: Admin approval system for student ID verification
- **Payment Integration**: Placeholder payment system for premium features
- **Admin Dashboard**: Separate interface for managing user verifications and platform statistics

## Authentication Flow
- **Replit OAuth**: Integration with Replit's OpenID Connect for secure authentication
- **Session Management**: Server-side session storage in PostgreSQL
- **Protected Routes**: Client and server-side route protection with automatic redirects
- **Profile Completion**: Multi-step onboarding process (registration → profile setup → verification → payment)

## State Management
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **React State**: Local component state for UI interactions and form management
- **URL State**: Navigation state managed by Wouter router

# External Dependencies

## Database & Storage
- **Neon Database**: Serverless PostgreSQL hosting
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## Authentication
- **Replit Auth**: OAuth provider using OpenID Connect
- **Passport.js**: Authentication middleware for Express

## Frontend Libraries
- **@tanstack/react-query**: Data fetching and caching
- **@radix-ui/***: Headless UI components (accordion, dialog, dropdown, etc.)
- **@react-spring/web**: Animation library for smooth transitions
- **@use-gesture/react**: Gesture recognition for swipe interactions
- **react-hook-form**: Form management
- **@hookform/resolvers**: Form validation resolvers
- **zod**: Runtime type validation
- **wouter**: Lightweight router

## Development & Build Tools
- **Vite**: Build tool with React plugin
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit-specific development features
- **TypeScript**: Type checking and compilation
- **Tailwind CSS**: Utility-first styling
- **PostCSS**: CSS processing with autoprefixer

## UI & Styling
- **Tailwind CSS**: Primary styling framework
- **class-variance-authority**: Component variant management
- **clsx + tailwind-merge**: Conditional class name utilities
- **Lucide React**: Icon library
- **cmdk**: Command palette component