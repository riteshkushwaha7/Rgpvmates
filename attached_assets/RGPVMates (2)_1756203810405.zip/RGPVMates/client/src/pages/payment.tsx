import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function Payment() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Auto redirect after showing success message
    const timer = setTimeout(() => {
      navigate("/");
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="text-center p-8">
          <div className="w-24 h-24 bg-green-100 rounded-full mx-auto mb-6 flex items-center justify-center">
            <Check className="text-green-600 text-3xl" data-testid="success-icon" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-4" data-testid="success-title">
            Payment Successful!
          </h2>
          
          <p className="text-gray-600 mb-8" data-testid="success-description">
            Your registration is complete. We're now verifying your RGPV ID card. 
            You'll receive an email confirmation once approved.
          </p>
          
          <Card className="bg-blue-50 border-blue-200 mb-6">
            <CardContent className="p-4">
              <div className="text-sm">
                <p className="font-medium text-blue-800 mb-2" data-testid="whats-next-title">
                  What's Next?
                </p>
                <ul className="text-blue-700 space-y-1 text-left">
                  <li data-testid="next-step-1">• Admin will review your ID card</li>
                  <li data-testid="next-step-2">• Approval usually takes 24 hours</li>
                  <li data-testid="next-step-3">• Check your email for updates</li>
                  <li data-testid="next-step-4">• Start swiping once approved!</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="w-full bg-rgpv-blue hover:bg-blue-700"
            data-testid="button-login"
          >
            Go to Login
          </Button>
          
          <p className="text-sm text-gray-500 mt-4" data-testid="auto-redirect-notice">
            You will be automatically redirected in 5 seconds...
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
