import { useLocation } from "wouter";
import { Heart, Shield, IdCard, MessageCircle, Star, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-rgpv-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-rgpv-pink rounded-lg flex items-center justify-center bounce-hearts">
              <Heart className="text-white text-lg" data-testid="logo-heart" />
            </div>
            <h1 className="text-xl font-bold text-gray-800" data-testid="app-title">RGPV Mates</h1>
          </div>
          <Button 
            variant="ghost" 
            className="text-rgpv-pink font-medium hover:bg-pink-50 button-click"
            onClick={() => window.location.href = '/api/login'}
            data-testid="header-login-button"
          >
            Login
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="flex-1 flex flex-col justify-center px-4 py-12 text-center relative overflow-hidden">
        {/* Floating animation elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="floating-elements absolute top-20 left-10 w-8 h-8 bg-pink-200 rounded-full opacity-60"></div>
          <div className="floating-elements absolute top-32 right-20 w-6 h-6 bg-pink-300 rounded-full opacity-40" style={{animationDelay: '2s'}}></div>
          <div className="floating-elements absolute bottom-40 left-20 w-4 h-4 bg-pink-400 rounded-full opacity-50" style={{animationDelay: '4s'}}></div>
          <div className="floating-elements absolute bottom-60 right-10 w-10 h-10 bg-pink-100 rounded-full opacity-30" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="max-w-md mx-auto relative z-10">
          <div className="mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-rgpv-pink to-rgpv-light rounded-full mx-auto mb-6 flex items-center justify-center pulse-glow">
              <GraduationCap className="text-white text-3xl" data-testid="hero-icon" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4" data-testid="hero-title">
              Find Your Campus Connection
            </h2>
            <p className="text-gray-600 leading-relaxed" data-testid="hero-description">
              Connect with college students in a safe, verified environment. Make meaningful connections on campus.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3 text-left" data-testid="feature-verified">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <Shield className="text-green-600 text-sm" />
              </div>
              <span className="text-gray-700">Verified College Students Only</span>
            </div>
            <div className="flex items-center space-x-3 text-left" data-testid="feature-id-verification">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <IdCard className="text-blue-600 text-sm" />
              </div>
              <span className="text-gray-700">ID Card Verification Required</span>
            </div>
            <div className="flex items-center space-x-3 text-left" data-testid="feature-chat">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <MessageCircle className="text-purple-600 text-sm" />
              </div>
              <span className="text-gray-700">Real-time Chat & Matching</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="space-y-3">
            <Button 
              className="w-full bg-rgpv-pink text-white py-4 rounded-xl font-semibold text-lg hover:bg-primary/90 button-click pulse-glow"
              onClick={() => navigate("/register")}
              data-testid="button-get-started"
            >
              Get Started - ₹99 Only
            </Button>
            <Button 
              variant="outline"
              className="w-full border-2 border-rgpv-pink text-rgpv-pink py-4 rounded-xl font-semibold hover:bg-pink-50 button-click"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-login"
            >
              Already a Member? Login
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-500 mb-2" data-testid="trust-indicator">
              Trusted by 500+ College Students
            </p>
            <div className="flex justify-center space-x-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="text-yellow-400 w-4 h-4 fill-current" data-testid={`star-${i}`} />
              ))}
              <span className="text-sm text-gray-600 ml-2" data-testid="rating">4.9/5 Rating</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
