import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProfileSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Camera } from "lucide-react";

// Extend the schema for form validation
const profileFormSchema = insertProfileSchema.extend({
  bio: z.string().max(500, "Bio must be less than 500 characters").optional(),
  graduationYear: z.enum(["2024", "2025", "2026", "2027", "2028", "2029", "2030"]),
});

type ProfileForm = z.infer<typeof profileFormSchema>;

export default function ProfileSetup() {
  const [, navigate] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      age: 20,
      gender: "male",
      branch: "computer-science",
      year: "2nd",
      graduationYear: "2025",
      bio: "",
    },
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: ProfileForm) => {
    setIsSubmitting(true);
    try {
      // Store profile data in localStorage for the demo
      localStorage.setItem('profileData', JSON.stringify({
        ...data,
        profilePicture: profileImage,
      }));
      navigate("/verification");
    } catch (error) {
      console.error("Profile setup error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-rgpv-bg">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center">
          <Button
            variant="ghost"
            size="sm"
            className="mr-4"
            onClick={() => navigate("/register")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800" data-testid="page-title">
            Setup Profile
          </h1>
        </div>
      </header>

      <div className="p-4 max-w-md mx-auto">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span data-testid="step-indicator">Step 2 of 3</span>
            <span data-testid="step-description">Profile Information</span>
          </div>
          <Progress value={66} className="w-full" data-testid="progress-bar" />
        </div>

        {/* Profile Photo Upload */}
        <div className="mb-8 text-center">
          <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center relative overflow-hidden">
            {profileImage ? (
              <img 
                src={profileImage} 
                alt="Profile" 
                className="w-full h-full object-cover" 
                data-testid="profile-image-preview"
              />
            ) : (
              <Camera className="text-gray-400 text-4xl" data-testid="camera-placeholder" />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
              data-testid="input-profile-image"
            />
          </div>
          <Button variant="link" className="text-rgpv-pink" data-testid="button-upload-photo">
            Upload Profile Photo
          </Button>
          <p className="text-xs text-gray-500 mt-1">Clear photo of your face required</p>
        </div>

        {/* Profile Form */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    min="18"
                    max="30"
                    {...form.register("age", { valueAsNumber: true })}
                    data-testid="input-age"
                  />
                  {form.formState.errors.age && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-age">
                      {form.formState.errors.age.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select 
                    value={form.watch("gender")} 
                    onValueChange={(value) => form.setValue("gender", value as any)}
                  >
                    <SelectTrigger data-testid="select-gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="non-binary">Non-binary</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.gender && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-gender">
                      {form.formState.errors.gender.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="branch">Branch</Label>
                  <Select 
                    value={form.watch("branch")} 
                    onValueChange={(value) => form.setValue("branch", value as any)}
                  >
                    <SelectTrigger data-testid="select-branch">
                      <SelectValue placeholder="Select branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="computer-science">Computer Science</SelectItem>
                      <SelectItem value="mechanical">Mechanical</SelectItem>
                      <SelectItem value="electrical">Electrical</SelectItem>
                      <SelectItem value="civil">Civil</SelectItem>
                      <SelectItem value="electronics">Electronics</SelectItem>
                      <SelectItem value="chemical">Chemical</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.branch && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-branch">
                      {form.formState.errors.branch.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Select 
                    value={form.watch("year")} 
                    onValueChange={(value) => form.setValue("year", value as any)}
                  >
                    <SelectTrigger data-testid="select-year">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1st">1st Year</SelectItem>
                      <SelectItem value="2nd">2nd Year</SelectItem>
                      <SelectItem value="3rd">3rd Year</SelectItem>
                      <SelectItem value="4th">4th Year</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.year && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-year">
                      {form.formState.errors.year.message}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="graduation-year">Graduation Year</Label>
                <Select 
                  value={form.watch("graduationYear")} 
                  onValueChange={(value) => form.setValue("graduationYear", value as any)}
                >
                  <SelectTrigger data-testid="select-graduation-year">
                    <SelectValue placeholder="Select graduation year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                    <SelectItem value="2026">2026</SelectItem>
                    <SelectItem value="2027">2027</SelectItem>
                    <SelectItem value="2028">2028</SelectItem>
                    <SelectItem value="2029">2029</SelectItem>
                    <SelectItem value="2030">2030</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">⚠️ Cannot be changed once set. ID verification valid until graduation.</p>
                {form.formState.errors.graduationYear && (
                  <p className="text-sm text-red-600 mt-1" data-testid="error-graduation-year">
                    {form.formState.errors.graduationYear.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  rows={4}
                  placeholder="Tell us about yourself, your interests, what you're looking for..."
                  {...form.register("bio")}
                  data-testid="textarea-bio"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Make it interesting and authentic</span>
                  <span data-testid="bio-character-count">
                    {form.watch("bio")?.length || 0}/500
                  </span>
                </div>
                {form.formState.errors.bio && (
                  <p className="text-sm text-red-600 mt-1" data-testid="error-bio">
                    {form.formState.errors.bio.message}
                  </p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-rgpv-pink hover:bg-primary/90 button-click"
                disabled={isSubmitting}
                data-testid="button-continue"
              >
                {isSubmitting ? "Saving Profile..." : "Continue to Verification"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
