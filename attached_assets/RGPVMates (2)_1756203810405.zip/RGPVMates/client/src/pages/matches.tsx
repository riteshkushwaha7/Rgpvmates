import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart } from "lucide-react";

export default function Matches() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: matches = [], isLoading, error } = useQuery<any[]>({
    queryKey: ["/api/matches"],
    retry: false,
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-rgpv-pink border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your matches...</p>
        </div>
      </div>
    );
  }

  // Get recent matches (last 3)
  const recentMatches = (matches as any[]).slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="flex items-center justify-between px-4 py-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/swipe")}
            data-testid="button-back"
          >
            <ArrowLeft className="text-gray-600" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800" data-testid="page-title">
            Your Matches
          </h1>
          <div className="w-10"></div>
        </div>
      </header>

      <div className="p-4">
        {/* New Matches */}
        {recentMatches.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-800 mb-4" data-testid="new-matches-title">
              New Matches
            </h2>
            <div className="flex space-x-4 overflow-x-auto pb-4">
              {recentMatches.map((match, index) => (
                <div
                  key={match.id}
                  onClick={() => navigate(`/chat/${match.id}`)}
                  className="flex-shrink-0 text-center cursor-pointer"
                  data-testid={`new-match-${index}`}
                >
                  <div className="relative">
                    <div className="w-20 h-20 rounded-full bg-gray-200 border-4 border-red-400 overflow-hidden">
                      {match.otherUser.profile?.profilePicture ? (
                        <img 
                          src={match.otherUser.profile.profilePicture} 
                          alt={`${match.otherUser.firstName || 'User'}'s profile`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold text-lg">
                          {(match.otherUser.firstName?.[0] || 'U').toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                      <Heart className="text-white text-xs" />
                    </div>
                  </div>
                  <p className="text-sm font-medium text-gray-800 mt-2" data-testid={`match-name-${index}`}>
                    {match.otherUser.firstName || 'Anonymous'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* All Matches */}
        <div>
          <h2 className="text-lg font-semibold text-gray-800 mb-4" data-testid="all-matches-title">
            {matches.length === 0 ? "No Matches Yet" : "Messages"}
          </h2>
          
          {matches.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-6 flex items-center justify-center">
                <Heart className="text-gray-400 text-3xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2" data-testid="no-matches-title">
                Start Swiping!
              </h3>
              <p className="text-gray-600 mb-6" data-testid="no-matches-description">
                Discover amazing people on campus and start making connections.
              </p>
              <Button
                onClick={() => navigate("/swipe")}
                className="bg-rgpv-blue hover:bg-blue-700"
                data-testid="button-start-swiping"
              >
                Start Swiping
              </Button>
            </div>
          ) : (
            <div className="space-y-1">
              {matches.map((match, index) => (
                <div
                  key={match.id}
                  onClick={() => navigate(`/chat/${match.id}`)}
                  className="flex items-center p-4 bg-white rounded-xl cursor-pointer hover:bg-gray-50 transition-colors"
                  data-testid={`match-item-${index}`}
                >
                  <div className="w-12 h-12 rounded-full bg-gray-200 mr-4 overflow-hidden">
                    {match.otherUser.profile?.profilePicture ? (
                      <img 
                        src={match.otherUser.profile.profilePicture} 
                        alt={`${match.otherUser.firstName || 'User'}'s profile`}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold">
                        {(match.otherUser.firstName?.[0] || 'U').toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold text-gray-800" data-testid={`match-user-name-${index}`}>
                        {match.otherUser.firstName || 'Anonymous'}
                      </h3>
                      <span className="text-xs text-gray-500" data-testid={`match-time-${index}`}>
                        {new Date(match.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 truncate" data-testid={`match-preview-${index}`}>
                      You matched! Start a conversation
                    </p>
                  </div>
                  <div className="w-3 h-3 bg-rgpv-blue rounded-full ml-2"></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
