import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Users, MessageCircle, Settings } from "lucide-react";

export default function Home() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: profile, isLoading: profileLoading, error } = useQuery<any>({
    queryKey: ["/api/profiles/me"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-rgpv-pink border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-4">Complete Your Profile</h2>
            <p className="text-gray-600 mb-6">
              You need to complete your profile setup before using RGPV Mates.
            </p>
            <Button 
              onClick={() => navigate("/register")}
              className="w-full bg-rgpv-pink hover:bg-primary/90 button-click"
              data-testid="button-complete-profile"
            >
              Complete Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (profile?.verificationStatus !== 'approved' || !profile?.isPaid) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-4">Account Pending</h2>
            {profile?.verificationStatus === 'pending' && (
              <p className="text-gray-600 mb-6">
                Your ID card is under review. You'll receive an email once approved.
              </p>
            )}
            {profile?.verificationStatus === 'rejected' && (
              <p className="text-red-600 mb-6">
                Your ID verification was rejected. Please contact support.
              </p>
            )}
            {!profile?.isPaid && (
              <p className="text-gray-600 mb-6">
                Please complete your payment to access the platform.
              </p>
            )}
            <Button 
              onClick={() => window.location.href = "/api/logout"}
              variant="outline"
              data-testid="button-logout"
            >
              Logout
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-rgpv-bg">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-rgpv-pink rounded-lg flex items-center justify-center bounce-hearts">
              <Heart className="text-white text-lg" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800" data-testid="welcome-title">
                Welcome, {(user as any)?.firstName}!
              </h1>
              <p className="text-sm text-gray-500">Ready to find your match?</p>
            </div>
          </div>
          <Button 
            variant="ghost"
            onClick={() => window.location.href = "/api/logout"}
            data-testid="button-logout-header"
          >
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-md mx-auto">
          {/* Start Swiping Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => navigate("/swipe")}
            data-testid="card-start-swiping"
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-rgpv-blue to-rgpv-light rounded-full mx-auto mb-4 flex items-center justify-center">
                <Heart className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Start Swiping</h3>
              <p className="text-gray-600 text-sm">Discover new connections</p>
            </CardContent>
          </Card>

          {/* View Matches Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => navigate("/matches")}
            data-testid="card-view-matches"
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Your Matches</h3>
              <p className="text-gray-600 text-sm">Chat with your connections</p>
            </CardContent>
          </Card>

          {/* Messages Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => navigate("/matches")}
            data-testid="card-messages"
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <MessageCircle className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Messages</h3>
              <p className="text-gray-600 text-sm">Continue conversations</p>
            </CardContent>
          </Card>

          {/* Settings Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => navigate("/profile-setup")}
            data-testid="card-settings"
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-gray-500 to-gray-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Settings className="text-white text-2xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Profile Settings</h3>
              <p className="text-gray-600 text-sm">Update your info</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
