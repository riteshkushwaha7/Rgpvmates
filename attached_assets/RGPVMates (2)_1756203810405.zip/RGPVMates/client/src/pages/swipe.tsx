import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Heart, X, MessageCircle, User } from "lucide-react";
import SwipeCard from "@/components/swipe-card";
import MatchModal from "@/components/match-modal";

export default function Swipe() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showMatchModal, setShowMatchModal] = useState(false);
  const [currentMatch, setCurrentMatch] = useState<any>(null);

  const { data: profiles = [], isLoading, error } = useQuery<any[]>({
    queryKey: ["/api/discover"],
    retry: false,
  });

  const swipeMutation = useMutation({
    mutationFn: async ({ swipedId, isLike }: { swipedId: string; isLike: boolean }) => {
      const response = await apiRequest("POST", "/api/swipes", {
        swipedId,
        isLike,
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      if (data.isMatch && variables.isLike) {
        setCurrentMatch((profiles as any[])[currentIndex]);
        setShowMatchModal(true);
      }
      setCurrentIndex(prev => prev + 1);
      
      // Invalidate matches query to update match list
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to process swipe. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  const handleSwipe = (isLike: boolean) => {
    const profile = (profiles as any[])[currentIndex];
    if (profile) {
      swipeMutation.mutate({
        swipedId: profile.id,
        isLike,
      });
    }
  };

  const handleCloseMatch = () => {
    setShowMatchModal(false);
    setCurrentMatch(null);
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rgpv-bg">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-rgpv-pink border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Finding your matches...</p>
        </div>
      </div>
    );
  }

  const currentProfile = (profiles as any[])[currentIndex];
  const nextProfile = (profiles as any[])[currentIndex + 1];
  const thirdProfile = (profiles as any[])[currentIndex + 2];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Navigation */}
      <header className="bg-white shadow-sm">
        <div className="flex justify-between items-center px-4 py-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            data-testid="button-profile"
          >
            <User className="text-gray-600 text-xl" />
          </Button>
          <div className="flex items-center space-x-2">
            <Heart className="text-rgpv-pink text-xl bounce-hearts" />
            <span className="font-bold text-gray-800" data-testid="app-name">RGPV Mates</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/matches")}
            className="relative"
            data-testid="button-matches"
          >
            <MessageCircle className="text-gray-600 text-xl" />
          </Button>
        </div>
      </header>

      {/* Card Stack Container */}
      <div className="flex-1 flex items-center justify-center p-4">
        {!currentProfile ? (
          <div className="text-center">
            <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-6 flex items-center justify-center">
              <Heart className="text-gray-400 text-4xl" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2" data-testid="no-more-profiles">
              No More Profiles
            </h3>
            <p className="text-gray-600 mb-6">
              Check back later for new matches or adjust your preferences.
            </p>
            <Button
              onClick={() => navigate("/matches")}
              className="bg-rgpv-blue hover:bg-blue-700"
              data-testid="button-view-matches"
            >
              View Your Matches
            </Button>
          </div>
        ) : (
          <div className="relative w-full max-w-sm card-stack">
            {/* Current Card */}
            <SwipeCard
              profile={currentProfile}
              zIndex={3}
              scale={1}
              onSwipe={handleSwipe}
              data-testid="swipe-card-current"
            />

            {/* Next Card */}
            {nextProfile && (
              <SwipeCard
                profile={nextProfile}
                zIndex={2}
                scale={0.95}
                data-testid="swipe-card-next"
              />
            )}

            {/* Third Card */}
            {thirdProfile && (
              <SwipeCard
                profile={thirdProfile}
                zIndex={1}
                scale={0.90}
                data-testid="swipe-card-third"
              />
            )}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      {currentProfile && (
        <div className="flex justify-center items-center space-x-8 pb-6">
          <Button
            variant="outline"
            size="lg"
            className="w-14 h-14 rounded-full border-2 border-gray-300 hover:border-gray-400"
            onClick={() => handleSwipe(false)}
            disabled={swipeMutation.isPending}
            data-testid="button-pass"
          >
            <X className="text-gray-500 text-xl" />
          </Button>
          <Button
            size="lg"
            className="w-14 h-14 rounded-full bg-red-500 hover:bg-red-600"
            onClick={() => handleSwipe(true)}
            disabled={swipeMutation.isPending}
            data-testid="button-like"
          >
            <Heart className="text-white text-xl" />
          </Button>
        </div>
      )}

      {/* Action Hints */}
      <div className="px-4 pb-6">
        <div className="flex justify-center items-center space-x-4 text-sm text-gray-500">
          <div className="flex items-center space-x-1">
            <X className="text-gray-400 w-4 h-4" />
            <span>Swipe left to pass</span>
          </div>
          <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          <div className="flex items-center space-x-1">
            <Heart className="text-red-400 w-4 h-4" />
            <span>Swipe right to like</span>
          </div>
        </div>
      </div>

      {/* Match Modal */}
      <MatchModal
        isOpen={showMatchModal}
        onClose={handleCloseMatch}
        matchedUser={currentMatch}
        currentUser={user as any}
        onStartChat={() => {
          handleCloseMatch();
          navigate("/matches");
        }}
      />
    </div>
  );
}
