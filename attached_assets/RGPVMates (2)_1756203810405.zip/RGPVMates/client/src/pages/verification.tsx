import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowLeft, IdCard, Upload, TriangleAlert, Check } from "lucide-react";

export default function Verification() {
  const [, navigate] = useLocation();
  const [idCardFile, setIdCardFile] = useState<File | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>("upi");
  const [isUploading, setIsUploading] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIdCardFile(file);
    }
  };

  const handleComplete = async () => {
    setIsUploading(true);
    try {
      // Store verification data in localStorage for the demo
      localStorage.setItem('verificationData', JSON.stringify({
        idCardUploaded: !!idCardFile,
        paymentMethod,
        timestamp: new Date().toISOString(),
      }));
      
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      navigate("/payment");
    } catch (error) {
      console.error("Verification error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-rgpv-bg">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center">
          <Button
            variant="ghost"
            size="sm"
            className="mr-4"
            onClick={() => navigate("/profile-setup")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800" data-testid="page-title">
            Verification
          </h1>
        </div>
      </header>

      <div className="p-4 max-w-md mx-auto">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span data-testid="step-indicator">Step 3 of 3</span>
            <span data-testid="step-description">ID & Payment</span>
          </div>
          <Progress value={100} className="w-full" data-testid="progress-bar" />
        </div>

        {/* ID Upload Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <IdCard className="w-5 h-5" />
              <span>Upload RGPV ID Card</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
              {idCardFile ? (
                <div className="text-green-600">
                  <Check className="w-8 h-8 mx-auto mb-2" />
                  <p className="font-medium" data-testid="file-uploaded">
                    {idCardFile.name}
                  </p>
                  <p className="text-sm text-gray-500">File uploaded successfully</p>
                </div>
              ) : (
                <>
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">Upload a clear photo of your RGPV Student ID</p>
                </>
              )}
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileUpload}
                className="hidden"
                id="id-card-upload"
                data-testid="input-id-card"
              />
              <Label htmlFor="id-card-upload">
                <Button variant="outline" className="cursor-pointer" data-testid="button-choose-file">
                  Choose File
                </Button>
              </Label>
              <p className="text-xs text-gray-500 mt-2">JPG, PNG or PDF (Max 5MB)</p>
            </div>
          </CardContent>
        </Card>

        {/* Payment Section */}
        <Card className="mb-8">
          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-rgpv-blue to-rgpv-light rounded-t-xl p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold" data-testid="payment-title">One-time Access Fee</h3>
                  <p className="text-blue-100 text-sm">Secure platform access</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold" data-testid="payment-amount">₹99</div>
                  <div className="text-blue-100 text-sm">Only</div>
                </div>
              </div>
              <div className="space-y-2 text-sm text-blue-100">
                <div className="flex items-center space-x-2">
                  <Check size={16} />
                  <span>Unlimited swipes and matches</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check size={16} />
                  <span>Real-time chat with matches</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check size={16} />
                  <span>24/7 customer support</span>
                </div>
              </div>
            </div>

            <div className="p-6">
              <h4 className="font-medium text-gray-800 mb-4">Choose Payment Method</h4>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="space-y-3">
                  <Label 
                    htmlFor="upi" 
                    className="flex items-center p-4 border border-gray-200 rounded-xl hover:border-rgpv-blue cursor-pointer transition-colors"
                    data-testid="payment-option-upi"
                  >
                    <RadioGroupItem value="upi" id="upi" className="mr-3" />
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-600 text-sm">📱</span>
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">UPI Payment</div>
                        <div className="text-sm text-gray-500">Pay with any UPI app</div>
                      </div>
                    </div>
                  </Label>
                  
                  <Label 
                    htmlFor="card" 
                    className="flex items-center p-4 border border-gray-200 rounded-xl hover:border-rgpv-blue cursor-pointer transition-colors"
                    data-testid="payment-option-card"
                  >
                    <RadioGroupItem value="card" id="card" className="mr-3" />
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 text-sm">💳</span>
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">Debit/Credit Card</div>
                        <div className="text-sm text-gray-500">Visa, Mastercard, RuPay</div>
                      </div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        {/* Complete Registration */}
        <Button
          onClick={handleComplete}
          className="w-full bg-rgpv-blue hover:bg-blue-700 mb-6"
          disabled={!idCardFile || isUploading}
          data-testid="button-complete-registration"
        >
          {isUploading ? "Processing..." : "Complete Registration & Pay ₹99"}
        </Button>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <TriangleAlert className="text-yellow-600 mt-1 flex-shrink-0" size={16} />
              <div className="text-sm">
                <p className="font-medium text-yellow-800" data-testid="verification-notice-title">
                  Verification Required
                </p>
                <p className="text-yellow-700" data-testid="verification-notice-description">
                  Your account will be activated after admin approval of your ID card (usually within 24 hours).
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
