import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Send, Heart, MoreVertical } from "lucide-react";

export default function Chat() {
  const { matchId } = useParams();
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get match info from matches query
  const { data: matches = [] } = useQuery<any[]>({
    queryKey: ["/api/matches"],
    retry: false,
  });

  const currentMatch = (matches as any[]).find((m: any) => m.id === matchId);

  const { data: messages = [], isLoading, error } = useQuery<any[]>({
    queryKey: ["/api/messages", matchId],
    retry: false,
    enabled: !!matchId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/messages", {
        matchId,
        content,
      });
      return response.json();
    },
    onSuccess: () => {
      setMessageText("");
      queryClient.invalidateQueries({ queryKey: ["/api/messages", matchId] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (messageText.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(messageText.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-rgpv-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading chat...</p>
        </div>
      </div>
    );
  }

  if (!currentMatch) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Match not found</h2>
          <Button onClick={() => navigate("/matches")} data-testid="button-back-to-matches">
            Back to Matches
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Chat Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="flex items-center px-4 py-3">
          <Button
            variant="ghost"
            size="sm"
            className="mr-4"
            onClick={() => navigate("/matches")}
            data-testid="button-back"
          >
            <ArrowLeft className="text-gray-600" />
          </Button>
          
          <div className="w-10 h-10 rounded-full bg-gray-200 mr-3 overflow-hidden">
            {currentMatch.otherUser.profile?.profilePicture ? (
              <img 
                src={currentMatch.otherUser.profile.profilePicture} 
                alt={`${currentMatch.otherUser.firstName || 'User'}'s profile`}
                className="w-full h-full object-cover"
                data-testid="chat-user-avatar"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-semibold">
                {(currentMatch.otherUser.firstName?.[0] || 'U').toUpperCase()}
              </div>
            )}
          </div>
          
          <div className="flex-1">
            <h1 className="font-semibold text-gray-800" data-testid="chat-user-name">
              {currentMatch.otherUser.firstName || 'Anonymous'}
            </h1>
            <p className="text-sm text-gray-500" data-testid="chat-user-info">
              {currentMatch.otherUser.profile?.branch?.replace('-', ' ').toUpperCase()}, {currentMatch.otherUser.profile?.year} Year
            </p>
          </div>
          
          <Button variant="ghost" size="sm" data-testid="button-more-options">
            <MoreVertical className="text-gray-600" />
          </Button>
        </div>
      </header>

      {/* Match Notification */}
      <div className="bg-gradient-to-r from-pink-50 to-red-50 border-b px-4 py-3">
        <div className="flex items-center justify-center text-center">
          <div className="flex items-center space-x-2">
            <Heart className="text-red-500 w-4 h-4" />
            <span className="text-sm text-gray-700" data-testid="match-notification">
              You matched with <span className="font-semibold">{currentMatch.otherUser.firstName}</span> on{" "}
              {new Date(currentMatch.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="messages-container">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 mt-8">
            <Heart className="w-8 h-8 mx-auto mb-2 text-red-400" />
            <p data-testid="no-messages">Start the conversation!</p>
          </div>
        ) : (
          messages.map((message: any, index: number) => {
            const isOwnMessage = message.senderId === user?.id;
            return (
              <div
                key={message.id}
                className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}
                data-testid={`message-${index}`}
              >
                <div
                  className={`max-w-xs rounded-2xl px-4 py-2 chat-bubble ${
                    isOwnMessage
                      ? "bg-rgpv-blue text-white"
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  <p data-testid={`message-content-${index}`}>{message.content}</p>
                  <p className={`text-xs mt-1 ${
                    isOwnMessage ? "text-blue-100" : "text-gray-500"
                  }`} data-testid={`message-time-${index}`}>
                    {new Date(message.createdAt).toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t px-4 py-3">
        <div className="flex items-center space-x-3">
          <div className="flex-1 bg-gray-100 rounded-full px-4 py-2 flex items-center">
            <Input
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="flex-1 bg-transparent border-none outline-none p-0 focus-visible:ring-0"
              data-testid="message-input"
            />
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!messageText.trim() || sendMessageMutation.isPending}
            className="w-10 h-10 bg-rgpv-blue rounded-full hover:bg-blue-700 p-0"
            data-testid="button-send"
          >
            <Send className="text-white w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
