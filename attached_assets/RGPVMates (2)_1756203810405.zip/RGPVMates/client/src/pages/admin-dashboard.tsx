import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Clock, 
  CheckCircle, 
  Heart, 
  DollarSign,
  Eye,
  Check,
  X
} from "lucide-react";

export default function AdminDashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: statsLoading } = useQuery<any>({
    queryKey: ["/api/admin/stats"],
    retry: false,
  });

  const { data: pendingVerifications = [], isLoading: verificationsLoading, error } = useQuery<any[]>({
    queryKey: ["/api/admin/pending-verifications"],
    retry: false,
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ profileId, status }: { profileId: string; status: 'approved' | 'rejected' }) => {
      const response = await apiRequest("PUT", `/api/admin/verify/${profileId}`, { status });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Verification status updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pending-verifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update verification status",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  const handleVerification = (profileId: string, status: 'approved' | 'rejected') => {
    verifyMutation.mutate({ profileId, status });
  };

  if (authLoading || statsLoading || verificationsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-rgpv-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Admin Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-rgpv-pink rounded-lg flex items-center justify-center">
              <Shield className="text-white" data-testid="admin-icon" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800" data-testid="admin-title">
                Admin Dashboard
              </h1>
              <p className="text-sm text-gray-500">RGPV Mates Management</p>
            </div>
          </div>
          <Button 
            variant="ghost"
            onClick={() => window.location.href = "/api/logout"}
            data-testid="button-logout"
          >
            Logout
          </Button>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Verifications</p>
                  <p className="text-2xl font-bold text-orange-600" data-testid="stat-pending">
                    {stats?.pending || 0}
                  </p>
                </div>
                <Clock className="text-orange-500 text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Verified Users</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="stat-verified">
                    {stats?.verified || 0}
                  </p>
                </div>
                <CheckCircle className="text-green-500 text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Matches</p>
                  <p className="text-2xl font-bold text-rgpv-pink" data-testid="stat-matches">
                    {stats?.matches || 0}
                  </p>
                </div>
                <Heart className="text-red-500 text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenue</p>
                  <p className="text-2xl font-bold text-purple-600" data-testid="stat-revenue">
                    ₹{stats?.revenue || 0}
                  </p>
                </div>
                <DollarSign className="text-purple-500 text-2xl" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Verifications Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>Pending ID Verifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(pendingVerifications as any[])?.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 mb-2" data-testid="no-pending-title">
                  All Caught Up!
                </h3>
                <p className="text-gray-600" data-testid="no-pending-description">
                  No pending verifications at the moment.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Submitted</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Card</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {(pendingVerifications as any[])?.map((verification: any, index: number) => (
                      <tr key={verification.id} className="hover:bg-gray-50" data-testid={`verification-row-${index}`}>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 mr-3 flex items-center justify-center text-white font-semibold">
                              {(verification.user.firstName?.[0] || 'U').toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium text-gray-800" data-testid={`user-name-${index}`}>
                                {verification.user.firstName} {verification.user.lastName}
                              </p>
                              <p className="text-sm text-gray-500" data-testid={`user-age-${index}`}>
                                {verification.age} years
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600" data-testid={`user-email-${index}`}>
                          {verification.user.email}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm">
                            <p className="text-gray-800" data-testid={`user-branch-${index}`}>
                              {verification.branch?.replace('-', ' ').toUpperCase()}
                            </p>
                            <p className="text-gray-500" data-testid={`user-year-${index}`}>
                              {verification.year} Year
                            </p>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500" data-testid={`submitted-time-${index}`}>
                          {new Date(verification.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4">
                          <Button 
                            variant="link" 
                            className="text-rgpv-blue p-0"
                            data-testid={`button-view-id-${index}`}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View ID Card
                          </Button>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                              onClick={() => handleVerification(verification.id, 'approved')}
                              disabled={verifyMutation.isPending}
                              data-testid={`button-approve-${index}`}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-red-50 text-red-700 border-red-200 hover:bg-red-100"
                              onClick={() => handleVerification(verification.id, 'rejected')}
                              disabled={verifyMutation.isPending}
                              data-testid={`button-reject-${index}`}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
