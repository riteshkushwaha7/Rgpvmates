import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Info } from "lucide-react";

const registrationSchema = z.object({
  email: z.string().email("Invalid email"),
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

type RegistrationForm = z.infer<typeof registrationSchema>;

export default function Registration() {
  const [, navigate] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<RegistrationForm>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      email: "",
      firstName: "",
      lastName: "",
      password: "",
    },
  });

  const onSubmit = async (data: RegistrationForm) => {
    setIsSubmitting(true);
    try {
      // Store registration data in localStorage for the demo
      localStorage.setItem('registrationData', JSON.stringify(data));
      navigate("/profile-setup");
    } catch (error) {
      console.error("Registration error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-rgpv-bg">
      {/* Header with Back Button */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center">
          <Button
            variant="ghost"
            size="sm"
            className="mr-4"
            onClick={() => navigate("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800" data-testid="page-title">
            Create Account
          </h1>
        </div>
      </header>

      <div className="p-4 max-w-md mx-auto">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-500 mb-2">
            <span data-testid="step-indicator">Step 1 of 3</span>
            <span data-testid="step-description">Account Details</span>
          </div>
          <Progress value={33} className="w-full" data-testid="progress-bar" />
        </div>

        {/* Registration Form */}
        <Card>
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@college.edu"
                  {...form.register("email")}
                  data-testid="input-email"
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-red-600 mt-1" data-testid="error-email">
                    {form.formState.errors.email.message}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Use your college email address
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    placeholder="John"
                    {...form.register("firstName")}
                    data-testid="input-first-name"
                  />
                  {form.formState.errors.firstName && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-first-name">
                      {form.formState.errors.firstName.message}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    {...form.register("lastName")}
                    data-testid="input-last-name"
                  />
                  {form.formState.errors.lastName && (
                    <p className="text-sm text-red-600 mt-1" data-testid="error-last-name">
                      {form.formState.errors.lastName.message}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Create a strong password"
                  {...form.register("password")}
                  data-testid="input-password"
                />
                {form.formState.errors.password && (
                  <p className="text-sm text-red-600 mt-1" data-testid="error-password">
                    {form.formState.errors.password.message}
                  </p>
                )}
              </div>

              <div className="bg-pink-50 border border-pink-200 rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <Info className="text-rgpv-pink mt-1 flex-shrink-0" size={16} />
                  <div className="text-sm">
                    <p className="font-medium text-gray-800 mb-1">Account Verification Required</p>
                    <p className="text-gray-600">
                      After registration, you'll need to upload your student ID card and pay ₹99 to access the platform.
                    </p>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-rgpv-pink hover:bg-primary/90 button-click"
                disabled={isSubmitting}
                data-testid="button-continue"
              >
                {isSubmitting ? "Creating Account..." : "Continue"}
              </Button>
            </form>

            <p className="text-center text-sm text-gray-500 mt-6">
              Already have an account?{" "}
              <Button
                variant="link"
                className="text-rgpv-pink p-0 h-auto"
                onClick={() => window.location.href = '/api/login'}
                data-testid="link-login"
              >
                Login here
              </Button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
