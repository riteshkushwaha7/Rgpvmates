import { useState, useCallback } from 'react';
import { useSpring } from '@react-spring/web';
import { useDrag } from '@use-gesture/react';

interface UseSwipeOptions {
  onSwipeComplete?: (direction: 'left' | 'right') => void;
  onSwipeStart?: () => void;
  onSwipeEnd?: () => void;
  threshold?: number;
}

export function useSwipe({
  onSwipeComplete,
  onSwipeStart,
  onSwipeEnd,
  threshold = 100,
}: UseSwipeOptions = {}) {
  const [isDragging, setIsDragging] = useState(false);

  const [{ x, rotate, scale, opacity }, api] = useSpring(() => ({
    x: 0,
    rotate: 0,
    scale: 1,
    opacity: 1,
    config: { friction: 50, tension: 500 },
  }));

  const bind = useDrag(
    ({ active, movement: [mx], direction: [xDir], velocity: [vx] }) => {
      // Trigger is either when the user releases the card or drags it beyond threshold
      const trigger = !active && (Math.abs(mx) > threshold || Math.abs(vx) > 0.5);
      
      if (active && !isDragging) {
        setIsDragging(true);
        onSwipeStart?.();
      }

      if (!active && isDragging) {
        setIsDragging(false);
        onSwipeEnd?.();
      }

      // If triggered, determine direction and complete swipe
      if (trigger) {
        const dir = xDir < 0 ? 'left' : 'right';
        const isLike = dir === 'right';
        
        // Animate card off screen
        api.start({
          x: (200 + window.innerWidth) * (isLike ? 1 : -1),
          rotate: mx / 100 + (isLike ? 10 : -10),
          scale: 1,
          opacity: 0,
          config: { friction: 50, tension: 200 },
        });

        // Call completion callback after animation
        setTimeout(() => {
          onSwipeComplete?.(dir);
          // Reset position for next card
          api.set({
            x: 0,
            rotate: 0,
            scale: 1,
            opacity: 1,
          });
        }, 200);
      } else {
        // Update position while dragging
        api.start({
          x: active ? mx : 0,
          rotate: active ? mx / 100 : 0,
          scale: active ? 1.1 : 1,
          opacity: active ? Math.max(0.5, 1 - Math.abs(mx) / 300) : 1,
          immediate: active,
        });
      }
    },
    {
      axis: 'x',
      bounds: { left: -200, right: 200 },
      rubberband: true,
    }
  );

  // Convert spring values to CSS transform string
  const transform = x.to((x) => `translateX(${x}px) rotate(${rotate.get()}deg)`);

  return {
    bind,
    transform,
    opacity,
    isDragging,
  };
}
